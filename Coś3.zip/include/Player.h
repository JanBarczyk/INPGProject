#ifndef PLAYER_H
#define PLAYER_H
#include "Animacja.h"

class Player
{
public:
    Player(sf::Texture* texturePtr, sf::Vector2u imageCount, float switchTime,float speed);
    ~Player();

    void update(float deltaTime);
    void draw(sf::RenderWindow& window);

private:
    sf::RectangleShape _body;
    Animacja _anim;
    unsigned int _row;
    float _speed;
    bool _faceRight;

};

#endif // PLAYER_H
