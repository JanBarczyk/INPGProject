#include "Player.h"

Player::Player(sf::Texture* texturePtr, sf::Vector2u imageCount, float switchTime, float speed) :
    _anim(texturePtr, imageCount, switchTime), _speed(speed)
{
    _row = 0;
    _faceRight = true;

    _body.setSize(sf::Vector2f(100.0f, 91.25f));
    _body.setPosition(sf::Vector2f(200.0f, 200.0f));
    _body.setTexture(texturePtr);
}

Player::~Player()
{
    //dtor
}

void Player::update(float deltaTime)
{
    sf::Vector2f movement(0.0f,0.0f);

    if(sf::Keyboard::isKeyPressed(sf::Keyboard::W))
        movement.y -= _speed * deltaTime;
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::S))
        movement.y += _speed * deltaTime;
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::A))
        movement.x -= _speed * deltaTime;
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::D))
        movement.x += _speed * deltaTime;

    if(movement.x == 0.0f || movement.y != 0.0f){
        _row = 0;
        _anim.update(_row,deltaTime,_faceRight);
        _body.setTextureRect(_anim._uvRect);
        _body.move(movement);
    } else {
        _row = 1;

        if(movement.x > 0.0f)
            _faceRight = true;
        if(movement.x < 0.0f)
            _faceRight = false;

        _anim.update(_row, deltaTime,_faceRight);
        _body.setTextureRect(_anim._uvRect);
        _body.move(movement);
    }

}
void Player::draw(sf::RenderWindow& window)
{
    window.draw(_body);
}
