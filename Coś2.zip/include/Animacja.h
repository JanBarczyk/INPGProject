#ifndef ANIMACJA_H
#define ANIMACJA_H

#include <SFML/Graphics.hpp>


class Animacja
{
public:
    Animacja(sf::Texture* texturePtr, sf::Vector2u imageCount, float switchTime);
    ~Animacja();

    void update(int row, float deltaTime, bool faceRight);

    sf::IntRect _uvRect;
private:
    sf::Vector2u _imageCount;
    sf::Vector2u _currentImage;

    float _totalTime;
    float _switchTime;
};

#endif // ANIMACJA_H
