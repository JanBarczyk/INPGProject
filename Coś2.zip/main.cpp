#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Player.h"

void func()
{
    sf::RenderWindow win(sf::VideoMode(100,100), "Thread");
    sf::CircleShape c(40.0f,30);
    c.setPosition(10.0f,10.0f);
    c.setFillColor(sf::Color::Yellow);

    while(win.isOpen()){
        sf::Event e2;
        while(win.pollEvent(e2)){
            switch(e2.type)
            {
            case sf::Event::Closed:
                std::cout<<"\nYou closed the window, thank you for your visit :) \n";
                win.close();
                break;
            case sf::Event::Resized:
                std::cout<<"\nNew window size: "<<e2.size.width<<" x "<<e2.size.height<<"\n";
                break;
            case sf::Event::TextEntered:
                if(e2.text.unicode < 128)
                    printf("%c",e2.text.unicode);
            }
        }
        win.clear();
        win.draw(c);
        win.display();
    }

}

int main()
{
    sf::RenderWindow window(sf::VideoMode(465,615), "Animacja!!!",sf::Style::Close | sf::Style::Resize);

    sf::Texture playerTexture;
    playerTexture.loadFromFile("images/Ghost.png");

    Player p1(&playerTexture,sf::Vector2u(9,4),0.07f,200.0f);
    float deltaTime = 0.0f;
    sf::Clock clock;

    while(window.isOpen()){
        deltaTime = clock.restart().asSeconds();
        sf::Event evnt;
        while(window.pollEvent(evnt)){
            switch(evnt.type)
            {
            case sf::Event::Closed:
                std::cout<<"\nYou closed the window, thank you for your visit :) \n";
                window.close();
                break;
            case sf::Event::Resized:
                std::cout<<"\nNew window size: "<<evnt.size.width<<" x "<<evnt.size.height<<"\n";
                break;
            case sf::Event::TextEntered:
                if(evnt.text.unicode < 128)
                    printf("%c",evnt.text.unicode);
                break;
            }
        }


        p1.update(deltaTime);

        window.clear();
        p1.draw(window);
        window.display();
    }
    return 0;
}
