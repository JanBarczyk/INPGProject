#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include <iostream>
#include "Animacja.h"

void func()
{
    sf::RenderWindow win(sf::VideoMode(100,100), "Thread");
    sf::CircleShape c(40.0f,30);
    c.setPosition(10.0f,10.0f);
    c.setFillColor(sf::Color::Yellow);

    while(win.isOpen()){
        sf::Event e2;
        while(win.pollEvent(e2)){
            switch(e2.type)
            {
            case sf::Event::Closed:
                std::cout<<"\nYou closed the window, thank you for your visit :) \n";
                win.close();
                break;
            case sf::Event::Resized:
                std::cout<<"\nNew window size: "<<e2.size.width<<" x "<<e2.size.height<<"\n";
                break;
            case sf::Event::TextEntered:
                if(e2.text.unicode < 128)
                    printf("%c",e2.text.unicode);
            }
        }
        win.clear();
        win.draw(c);
        win.display();
    }

}

int main()
{
    sf::RenderWindow window(sf::VideoMode(1920,1000), "Dupa dupa!!!",sf::Style::Close | sf::Style::Resize);
    sf::RectangleShape rect(sf::Vector2f(108.0f, 140.0f));
    rect.setPosition(sf::Vector2f(100.0f, 100.0f));
    //rect.setFillColor(sf::Color::Magenta);
    rect.setOrigin(20.0f, 20.0f);

    sf::Texture playerTexture;
    playerTexture.loadFromFile("images/Animacja.png");
    rect.setTexture(&playerTexture);

    Animacja animation(&playerTexture,sf::Vector2u(8,2),0.07f);
    float deltaTime = 0.0f;
    sf::Clock clock;

    while(window.isOpen()){
        deltaTime = clock.restart().asSeconds();
        sf::Event evnt;
        while(window.pollEvent(evnt)){
            switch(evnt.type)
            {
            case sf::Event::Closed:
                std::cout<<"\nYou closed the window, thank you for your visit :) \n";
                window.close();
                break;
            case sf::Event::Resized:
                std::cout<<"\nNew window size: "<<evnt.size.width<<" x "<<evnt.size.height<<"\n";
                break;
            case sf::Event::TextEntered:
                if(evnt.text.unicode < 128)
                    printf("%c",evnt.text.unicode);
                break;
            }
        }
        //moving with Keyboard
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::W) || sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad8))
            rect.move(0.0f, -1.0f);
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::S)|| sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad2))
            rect.move(0.0f, 1.0f);
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::A)|| sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad4)){
            animation.setFaceRight(false);
            rect.move(-1.0f, 0.0f);
        }
        if(sf::Keyboard::isKeyPressed(sf::Keyboard::D)|| sf::Keyboard::isKeyPressed(sf::Keyboard::Numpad6)){
            animation.setFaceRight(true);
            rect.move(1.0f, 0.0f);
        }
        //moving with Mouse
        if(sf::Mouse::isButtonPressed((sf::Mouse::Left))){
            sf::Vector2i mousePos = sf::Mouse::getPosition(window);
            rect.setPosition((float)(mousePos.x), static_cast<float>(mousePos.y));
        }

        animation.update(0,deltaTime);
        rect.setTextureRect(animation._uvRect);

        window.clear();
        window.draw(rect);
        window.display();
    }
    return 0;
}
