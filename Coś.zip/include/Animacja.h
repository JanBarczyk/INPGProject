#ifndef ANIMACJA_H
#define ANIMACJA_H

#include <SFML/Graphics.hpp>


class Animacja
{
public:
    Animacja(sf::Texture* texturePtr, sf::Vector2u imageCount, float switchTime);
    ~Animacja();

    void update(int row, float deltaTime);
    void setFaceRight(bool right){ if(right) _faceRight = true;
                                    else _faceRight = false;}

    sf::IntRect _uvRect;
private:
    sf::Vector2u _imageCount;
    sf::Vector2u _currentImage;

    bool _faceRight;

    float _totalTime;
    float _switchTime;
};

#endif // ANIMACJA_H
