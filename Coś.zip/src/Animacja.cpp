#include "Animacja.h"

Animacja::Animacja(sf::Texture* texturePtr, sf::Vector2u imageCount, float switchTime) : _imageCount(imageCount), _switchTime(switchTime)
{
    _totalTime = 0.0f;
    _currentImage.x = 0;
    _currentImage.y = 0;

    _uvRect.width = texturePtr->getSize().x /(float)_imageCount.x;
    _uvRect.height = texturePtr->getSize().y /(float)_imageCount.y;
}

Animacja::~Animacja()
{
    //dtor
}

void Animacja::update(int row, float deltaTime)
{
    _currentImage.y = row;

    _totalTime += deltaTime;

    if(_totalTime >= _switchTime){
        _totalTime -= _switchTime;
        _currentImage.x ++;

        if(_currentImage.x >= _imageCount.x){
            _currentImage.x = 0;
        }
    }
    _uvRect.top = _currentImage.y * _uvRect.height;
    if(_faceRight){
            _uvRect.left = _currentImage.x * _uvRect.width;
            _uvRect.width = abs(_uvRect.width);
    }else{
        _uvRect.left = (_currentImage.x -1)*abs(_uvRect.width);
        _uvRect.width = -abs(_uvRect.width);
    }
}
